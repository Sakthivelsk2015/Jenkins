package com.fazon.simplybytespringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimplyByteSpringbootApplicationTests {

    @Test
    void contextLoads() {
    }

}
